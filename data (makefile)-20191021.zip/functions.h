extern double exponential(double lambda, long *seed); 
extern void schedule(event_type_t type, double time); 

